import { BadRequestException } from '@nestjs/common';
import { z } from 'zod';
export const digits = (value: string) =>
  value.replace(/[٠-٩۰-۹]/g, (c) =>
    String(c.charCodeAt(0) - (c <= '٩' ? 1632 : 1776)),
  );
export const cleanText = (value: string) => value.trim().replace(/\s+/g, ' ');
export const categories = ['MARTYR', 'WAR_INJURED', 'EXTREME_POVERTY'] as const;
export const categorySchema = z.enum(categories, {
  error: 'نوع الإحصاء غير صحيح',
});
export const uuidSchema = z.uuid({ error: 'المعرّف غير صحيح' });
export function parse<T>(schema: z.ZodType<T>, value: unknown): T {
  const result = schema.safeParse(value);
  if (!result.success)
    throw new BadRequestException({
      code: 'VALIDATION_ERROR',
      message: 'يرجى التحقق من البيانات',
      fields: Object.fromEntries(
        result.error.issues.map((i) => [i.path.join('.'), i.message]),
      ),
    });
  return result.data;
}
export const shortText = (max: number) =>
  z
    .string({ error: 'يجب إدخال نص' })
    .transform(cleanText)
    .pipe(
      z
        .string()
        .min(1, 'هذا الحقل مطلوب')
        .max(max, 'النص أطول من الحد المسموح'),
    );
const optionalText = (max: number, numeric = false) =>
  z
    .string({ error: 'يجب إدخال نص' })
    .max(max, 'النص أطول من الحد المسموح')
    .nullish()
    .transform((v) =>
      v ? (numeric ? digits(v.trim()) : v.trim()) || null : null,
    );
export const recordSchema = z
  .object({
    category: categorySchema,
    municipalityId: uuidSchema.optional(),
    personName: shortText(200),
    maritalStatus: z
      .enum(['SINGLE', 'MARRIED'], {
        error: 'الحالة الاجتماعية يجب أن تكون عازب أو متزوج',
      })
      .nullish(),
    spouseName: optionalText(200),
    nationalId: optionalText(50, true),
    familyBookNumber: optionalText(50, true),
    familyMembersCount: z.preprocess(
      (v) => (typeof v === 'string' && v.trim() ? Number(digits(v.trim())) : v),
      z
        .number({
          error: 'عدد أفراد الأسرة يجب أن يكون رقماً صحيحاً أكبر من صفر',
        })
        .int('عدد أفراد الأسرة يجب أن يكون عدداً صحيحاً')
        .min(1, 'عدد أفراد الأسرة يجب أن يكون أكبر من صفر')
        .max(10000, 'عدد أفراد الأسرة يتجاوز الحد المسموح'),
    ),
    phone: optionalText(50, true),
    notes: optionalText(2000),
    expectedUpdatedAt: z.iso.datetime().optional(),
  })
  .strict()
  .superRefine((v, ctx) => {
    if (v.category !== 'EXTREME_POVERTY') {
      if (!v.maritalStatus)
        ctx.addIssue({
          code: 'custom',
          path: ['maritalStatus'],
          message: 'الحالة الاجتماعية مطلوبة',
        });
      if (v.maritalStatus === 'MARRIED' && !v.spouseName)
        ctx.addIssue({
          code: 'custom',
          path: ['spouseName'],
          message: 'اسم الزوجة مطلوب للمتزوج',
        });
    }
  })
  .transform((v) => ({
    ...v,
    maritalStatus:
      v.category === 'EXTREME_POVERTY' ? null : (v.maritalStatus ?? null),
    spouseName:
      v.maritalStatus === 'SINGLE' && v.category !== 'EXTREME_POVERTY'
        ? null
        : v.spouseName,
  }));
export type RecordInput = z.infer<typeof recordSchema>;
export const paginationSchema = z.object({
  page: z.coerce.number().int().min(1).max(100000).default(1),
  pageSize: z.coerce.number().int().min(1).max(100).default(25),
});
export const recordQuerySchema = paginationSchema
  .extend({
    category: categorySchema.optional(),
    municipalityId: uuidSchema.optional(),
    search: z.string().trim().max(100).optional(),
    deleted: z.enum(['true', 'false']).default('false'),
  })
  .strict();
export const passwordSchema = z
  .string()
  .min(12, 'كلمة المرور يجب أن تكون 12 محرفاً على الأقل')
  .max(128, 'كلمة المرور طويلة جداً');
export const usernameSchema = z
  .string()
  .trim()
  .toLowerCase()
  .regex(
    /^[a-z0-9_.-]{3,80}$/,
    'اسم المستخدم: 3 إلى 80 محرفاً من الحروف اللاتينية والأرقام و . _ -',
  );
