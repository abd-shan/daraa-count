import { recordSchema, digits } from './validation';
const base = {
  category: 'MARTYR',
  personName: '  أحمد   سعيد حسين  ',
  familyMembersCount: '٣',
  maritalStatus: 'SINGLE',
  nationalId: '٠٠١٢٣',
  phone: '٠٩٤٤٠٠٠٠٠٠',
};
describe('Record validation', () => {
  it('preserves names and leading zeros while normalizing digits', () => {
    const result = recordSchema.parse(base);
    expect(result.personName).toBe('أحمد سعيد حسين');
    expect(result.nationalId).toBe('00123');
    expect(result.phone).toBe('0944000000');
    expect(result.familyMembersCount).toBe(3);
    expect(digits('۰۱۲٣')).toBe('0123');
  });
  it('clears spouse when single', () =>
    expect(
      recordSchema.parse({ ...base, spouseName: 'قيمة قديمة' }).spouseName,
    ).toBeNull());
  it('requires spouse for married and marital status for martyr/injured', () => {
    expect(
      recordSchema.safeParse({ ...base, maritalStatus: 'MARRIED' }).success,
    ).toBe(false);
    expect(
      recordSchema.safeParse({
        ...base,
        category: 'WAR_INJURED',
        maritalStatus: null,
      }).success,
    ).toBe(false);
    expect(
      recordSchema.parse({
        ...base,
        maritalStatus: 'MARRIED',
        spouseName: 'اسم الزوجة',
      }).spouseName,
    ).toBe('اسم الزوجة');
  });
  it('allows poverty without spouse or marital status', () => {
    expect(
      recordSchema.parse({
        ...base,
        category: 'EXTREME_POVERTY',
        maritalStatus: undefined,
      }).maritalStatus,
    ).toBeNull();
    expect(
      recordSchema.parse({
        ...base,
        category: 'EXTREME_POVERTY',
        spouseName: 'اسم اختياري',
      }).spouseName,
    ).toBe('اسم اختياري');
  });
  it.each([0, -1, 1.5, '', 'abc', null, 10001])(
    'rejects invalid family count %s',
    (value) =>
      expect(
        recordSchema.safeParse({ ...base, familyMembersCount: value }).success,
      ).toBe(false),
  );
  it('rejects unknown fields, invalid category, empty names and numeric identifiers', () => {
    for (const input of [
      { ...base, createdById: 'forged' },
      { ...base, category: 'OTHER' },
      { ...base, personName: ' ' },
      { ...base, nationalId: 123 },
    ])
      expect(recordSchema.safeParse(input).success).toBe(false);
  });
});
